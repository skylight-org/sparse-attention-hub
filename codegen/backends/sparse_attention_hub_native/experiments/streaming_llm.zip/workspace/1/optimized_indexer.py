"""Optimized custom indexer using Triton kernels for Sink + Local attention.

This indexer implements the same sparse attention pattern as gen_imperative_code.py,
but uses Triton kernels to fuse operations and reduce memory allocations.

Optimization Strategy (Iteration 1):
1. Fuse sparse_list and weight_list generation into a single Triton kernel
2. Eliminate intermediate tensor allocations
3. Use parallel generation for better GPU utilization
"""

from typing import Any, Dict, Tuple

import torch
import triton
import triton.language as tl
from codegen.custom_attention_hub import sparse_attention_config


@triton.jit
def sparse_pattern_kernel(
    # Outputs
    sparse_list_ptr,
    weight_list_ptr,
    sparse_len_ptr,
    # Input params
    batch_size: tl.constexpr,
    num_heads: tl.constexpr,
    seq_len_k: tl.constexpr,
    sink_size: tl.constexpr,
    window_size: tl.constexpr,
    # Strides
    sparse_list_stride_b: tl.constexpr,
    sparse_list_stride_h: tl.constexpr,
    sparse_list_stride_s: tl.constexpr,
    weight_list_stride_b: tl.constexpr,
    weight_list_stride_h: tl.constexpr,
    weight_list_stride_s: tl.constexpr,
    sparse_len_stride_b: tl.constexpr,
    sparse_len_stride_h: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """Fused kernel to generate sparse_list and weight_list.
    
    This kernel generates:
    1. sparse_list: indices of tokens to attend to (sink + local)
    2. weight_list: weights for all tokens (1.0 for attended, 0.0 for others)
    3. sparse_len: number of attended tokens per batch/head
    """
    # Program ID: one per (batch, head) pair
    pid: tl.int32 = tl.program_id(0)
    
    # Decode batch and head indices
    batch_idx: tl.int32 = pid // num_heads
    head_idx: tl.int32 = pid % num_heads
    
    # Total number of attended tokens
    attended_len: tl.int32 = sink_size + window_size
    
    # Write sparse_len
    sparse_len_offset: tl.int64 = batch_idx * sparse_len_stride_b + head_idx * sparse_len_stride_h
    tl.store(sparse_len_ptr + sparse_len_offset, attended_len)
    
    # Generate sparse_list (sink + local tokens)
    # Process in blocks for efficiency
    for block_start in range(0, attended_len, BLOCK_SIZE):
        offsets: tl.tensor = block_start + tl.arange(0, BLOCK_SIZE)
        mask: tl.tensor = offsets < attended_len
        
        # Compute token indices:
        # First sink_size positions: [0, 1, 2, ..., sink_size-1]
        # Next window_size positions: [seq_len_k - window_size, ..., seq_len_k - 1]
        token_idx: tl.tensor = tl.where(
            offsets < sink_size,
            offsets,  # Sink tokens
            seq_len_k - window_size + (offsets - sink_size)  # Local window tokens
        )
        
        # Write to sparse_list
        sparse_list_offset: tl.int64 = (
            batch_idx * sparse_list_stride_b +
            head_idx * sparse_list_stride_h +
            offsets * sparse_list_stride_s
        )
        tl.store(sparse_list_ptr + sparse_list_offset, token_idx, mask=mask)
    
    # Generate weight_list (per-token weights)
    # Process sequence in blocks
    for block_start in range(0, seq_len_k, BLOCK_SIZE):
        offsets: tl.tensor = block_start + tl.arange(0, BLOCK_SIZE)
        mask: tl.tensor = offsets < seq_len_k
        
        # Weight is 1.0 if token is in sink (< sink_size) or local window (>= seq_len_k - window_size)
        # Otherwise 0.0
        is_sink: tl.tensor = offsets < sink_size
        is_local: tl.tensor = offsets >= (seq_len_k - window_size)
        weight: tl.tensor = tl.where(is_sink | is_local, 1.0, 0.0)
        
        # Write to weight_list
        weight_list_offset: tl.int64 = (
            batch_idx * weight_list_stride_b +
            head_idx * weight_list_stride_h +
            offsets * weight_list_stride_s
        )
        tl.store(weight_list_ptr + weight_list_offset, weight, mask=mask)


def __indexer(
    queries: torch.Tensor,
    keys: torch.Tensor,
    values: torch.Tensor,
    sparse_list: torch.Tensor,
    sparse_len: torch.Tensor,
    weight_list: torch.Tensor,
    **kwargs: Dict[str, Any],
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Optimized indexer using Triton kernel for Sink (128) + Local (128) attention.
    
    This function modifies the sparse attention pattern to attend only to:
    1. First 128 tokens (sink tokens)
    2. Last 128 tokens (local window)
    
    Args:
        queries: Query tensor of shape ``(batch_size, num_heads, head_dim)``.
        keys: Key tensor of shape ``(batch_size, num_heads, seq_len_k, head_dim)``.
        values: Value tensor of shape ``(batch_size, num_heads, seq_len_k, head_dim)``.
        sparse_list: Tensor of shape ``(batch_size, num_heads, seq_len_k)``
            containing token indices to attend to (not used, replaced).
        sparse_len: Tensor of shape ``(batch_size, num_heads)`` indicating
            the valid length in sparse_list (not used, replaced).
        weight_list: Tensor of shape ``(batch_size, num_heads, seq_len_k)``
            containing per-token weights (not used, replaced).
        **kwargs: Additional keyword arguments (unused).
    
    Returns:
        Tuple of (sparse_list, sparse_len, weight_list) modified to implement
        the sink + local attention pattern using optimized Triton kernels.
    """
    # Configuration
    sink_size: int = sparse_attention_config.masker_configs[0].sink_size
    window_size: int = sparse_attention_config.masker_configs[1].window_size
    
    # Extract dimensions
    batch_size: int = keys.shape[0]
    num_heads: int = keys.shape[1]
    seq_len_k: int = keys.shape[2]
    
    device: torch.device = keys.device
    dtype: torch.dtype = weight_list.dtype
    
    # Handle case where sequence is shorter than sink + window
    if seq_len_k <= sink_size + window_size:
        # Use full attention - return all tokens
        return sparse_list, sparse_len, weight_list
    
    # Allocate output tensors
    attended_len: int = sink_size + window_size
    new_sparse_list: torch.Tensor = torch.empty(
        (batch_size, num_heads, attended_len),
        dtype=torch.int32,
        device=device
    )
    
    new_sparse_len: torch.Tensor = torch.empty(
        (batch_size, num_heads),
        dtype=torch.int32,
        device=device
    )
    
    new_weight_list: torch.Tensor = torch.empty(
        (batch_size, num_heads, seq_len_k),
        dtype=dtype,
        device=device
    )
    
    # Launch kernel with one program per (batch, head) pair
    num_programs: int = batch_size * num_heads
    BLOCK_SIZE: int = 128  # Process 128 elements at a time
    
    sparse_pattern_kernel[(num_programs,)](
        # Outputs
        new_sparse_list,
        new_weight_list,
        new_sparse_len,
        # Input params
        batch_size,
        num_heads,
        seq_len_k,
        sink_size,
        window_size,
        # Strides for sparse_list [B, H, S_attended]
        new_sparse_list.stride(0),
        new_sparse_list.stride(1),
        new_sparse_list.stride(2),
        # Strides for weight_list [B, H, S_full]
        new_weight_list.stride(0),
        new_weight_list.stride(1),
        new_weight_list.stride(2),
        # Strides for sparse_len [B, H]
        new_sparse_len.stride(0),
        new_sparse_len.stride(1),
        # Block size
        BLOCK_SIZE=BLOCK_SIZE,
    )
    
    return new_sparse_list, new_sparse_len, new_weight_list

