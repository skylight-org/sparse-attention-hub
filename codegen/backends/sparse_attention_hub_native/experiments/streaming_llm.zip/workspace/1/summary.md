# Iteration 1: Fused Triton Kernel for Sparse Pattern Generation

## Optimization Strategy

**Goal**: Replace PyTorch-based tensor operations with a fused Triton kernel to reduce memory allocations and improve GPU utilization.

**Approach**:
1. Implemented a single Triton kernel (`sparse_pattern_kernel`) that fuses three operations:
   - `sparse_list` generation (sink + local token indices)
   - `weight_list` generation (per-token weights)
   - `sparse_len` generation (number of attended tokens)
2. Used parallel processing with one CUDA program per (batch, head) pair
3. Eliminated intermediate tensor allocations by direct GPU memory writes
4. Used block-based processing (BLOCK_SIZE=128) for efficient memory access patterns

## Implementation Details

**Baseline (gen_imperative_code.py)**:
- Created separate tensors using `torch.zeros`, `torch.arange`, `torch.full`
- Used tensor slicing and broadcasting for assignments
- Multiple memory allocations and copies

**Optimized (Iteration 1)**:
- Single Triton kernel with fused operations
- Direct memory writes using `tl.store`
- Vectorized operations with block-based processing
- Eliminated redundant allocations

## Timing Results

### Baseline Performance
```
custom_indexer_hub:
  Average Time: 0.106 ms
  Min Time:     0.096 ms
  Max Time:     0.324 ms

custom __indexer:
  Average Time: 0.091 ms
  Min Time:     0.083 ms
  Max Time:     0.239 ms
```

### Iteration 1 Performance
```
custom_indexer_hub:
  Average Time: 0.111 ms  (+4.7% vs baseline)
  Min Time:     0.095 ms
  Max Time:     0.322 ms

custom __indexer:
  Average Time: 0.039 ms  (-57.1% vs baseline, 2.3x speedup!)
  Min Time:     0.034 ms  (-59.0% vs baseline)
  Max Time:     0.150 ms  (-37.2% vs baseline)
```

### Performance Summary
- **Speedup**: 2.3x faster (0.091 ms → 0.039 ms)
- **Reduction**: 57.1% time reduction
- **Consistency**: More stable performance (max time improved by 37%)

## Profile Analysis

### Key Observations from Trace Files

**CUDA Kernel Timing** (from profile.log):
- Triton kernel `sparse_pattern_kernel`: 8.544 μs CUDA time
- Extremely efficient GPU utilization with single kernel launch
- Minimal CPU-GPU synchronization overhead

**Top Operations by CUDA Time**:
1. `sparse_pattern_kernel`: 8.544 μs (100% of CUDA time in indexer)
2. Very low overhead - kernel launch overhead is minimal

**Memory Efficiency**:
- CUDA Memory allocated: 2.03 MB (compact representation)
- No intermediate allocations visible in profiling
- Efficient memory access patterns

### Comparison with Baseline

**Baseline Issues**:
- Multiple PyTorch operations (`zeros`, `arange`, `fill_`, `index_put_`)
- Tensor slicing and broadcasting overhead
- Multiple kernel launches for different operations
- Higher memory allocation overhead

**Iteration 1 Improvements**:
- Single kernel launch (1 vs ~5-6 operations in baseline)
- Fused computation reduces memory traffic
- Direct GPU writes eliminate intermediate buffers
- Better GPU occupancy with parallel (batch, head) processing

## Opportunities for Further Optimization

1. **Memory Coalescing**: 
   - Current implementation uses simple strided access patterns
   - Could optimize memory access patterns for better coalescing
   - Consider reordering data layout for sequential access

2. **Kernel Fusion with Backend**:
   - Currently only optimized the indexer phase
   - Could fuse sparse_pattern generation with the actual attention computation
   - Eliminate the need to materialize sparse_list and weight_list

3. **Block Size Tuning**:
   - Current BLOCK_SIZE=128 is chosen arbitrarily
   - Could benchmark different block sizes (64, 256, 512)
   - Optimal block size may depend on GPU architecture and sequence length

4. **Reduce Redundant Computation**:
   - sink_indices and local_indices are the same across all batches/heads
   - Could compute once and broadcast/reuse
   - May not help much due to low compute intensity

5. **Vectorization**:
   - Current implementation processes elements one at a time within blocks
   - Could use wider vector loads/stores (e.g., int4, float4)
   - Better utilize memory bandwidth

6. **Conditional Execution**:
   - The kernel always writes sparse_len even though it's constant
   - Could compute sparse_len on CPU and skip GPU write
   - Minor optimization but reduces kernel work

## Next Steps for Iteration 2

**Primary Focus**: Block size tuning and memory coalescing optimization

**Plan**:
1. Benchmark different BLOCK_SIZE values (64, 256, 512, 1024)
2. Optimize memory access patterns for better coalescing
3. Profile memory bandwidth utilization using nsight compute
4. Consider vectorized loads/stores for weight_list generation

**Expected Impact**: 
- Additional 20-30% speedup from better memory coalescing
- More consistent performance across different sequence lengths

