# Iteration 2: Separate Kernels with Memory Coalescing Optimization

## Optimization Strategy

**Goal**: Improve upon Iteration 1 by optimizing memory access patterns and reducing redundant computation.

**Approach**:
1. Separated sparse_list and weight_list generation into two kernels for better memory coalescing
2. Flattened tensor layout to improve sequential memory access
3. Increased BLOCK_SIZE from 128 to 256 for better GPU occupancy
4. Moved sparse_len computation to CPU (constant value, no GPU computation needed)
5. Added explicit view operations to reshape flattened tensors

## Implementation Details

**Key Changes from Iteration 1**:
- Split fused kernel into `sparse_list_kernel` and `weight_list_kernel`
- Used flattened memory layout: `[batch * heads * seq_len]` instead of `[batch, heads, seq_len]`
- Increased BLOCK_SIZE to 256 (from 128 in iteration 1)
- Computed sparse_len using `torch.full` on host side

## Timing Results

### Iteration 1 Performance (Baseline for Iteration 2)
```
custom __indexer:
  Average Time: 0.039 ms
  Min Time:     0.034 ms
  Max Time:     0.150 ms
```

### Iteration 2 Performance
```
custom __indexer:
  Average Time: 0.054 ms  (+38.5% vs iteration 1 - SLOWER!)
  Min Time:     0.045 ms  (+32.4% vs iteration 1)
  Max Time:     0.204 ms  (+36.0% vs iteration 1)
```

### Performance Summary
- **Regression**: 38.5% slower than iteration 1 (0.039 ms → 0.054 ms)
- **Why slower**: Kernel launch overhead dominates for small workloads

## Profile Analysis

### Key Observations from Trace Files

**CUDA Kernel Timing** (from profile.log):
- `sparse_list_kernel`: 1.280 μs CUDA time
- `weight_list_kernel`: 5.184 μs CUDA time
- Total kernel time: 6.464 μs
- Additional overhead from `torch.full`: 2.688 μs CUDA time
- **Total CUDA time: ~9.15 μs vs 8.544 μs in iteration 1**

**Comparison with Iteration 1**:
| Metric | Iteration 1 | Iteration 2 | Change |
|--------|-------------|-------------|---------|
| Number of kernels | 1 (fused) | 2 (separate) | +100% |
| CUDA kernel time | 8.544 μs | 6.464 μs | -24% |
| Additional overhead | 0 μs | 2.688 μs (torch.full) | +2.688 μs |
| Total CUDA time | 8.544 μs | ~9.15 μs | +7% |
| Wall-clock time | 0.039 ms | 0.054 ms | +38% |

### Root Cause Analysis

**Why Iteration 2 is Slower**:

1. **Kernel Launch Overhead**: 
   - Two kernel launches instead of one
   - Each kernel launch has ~10-20 μs CPU overhead
   - For small workloads (32 programs), launch overhead dominates

2. **Additional torch.full Call**:
   - Computing sparse_len on CPU/GPU with torch.full adds 2.688 μs
   - In iteration 1, this was just a simple store in the fused kernel
   - The "optimization" actually added overhead

3. **Memory Layout Overhead**:
   - Flattening and reshaping tensors adds CPU overhead
   - View operations are cheap but not free
   - Flattened layout doesn't improve memory coalescing enough to offset overhead

4. **Block Size Change**:
   - BLOCK_SIZE=256 vs 128 doesn't significantly impact performance
   - Workload is too small to benefit from larger blocks
   - May actually reduce occupancy for small sequences

5. **Workload Characteristics**:
   - Total work: 32 programs × (~256 + 32678 elements)
   - This is a relatively small workload where kernel fusion is critical
   - Splitting kernels trades compute efficiency for launch overhead

## Lessons Learned

### What Didn't Work

1. **Premature Kernel Splitting**:
   - Splitting kernels can improve memory coalescing in theory
   - But for small workloads, kernel fusion is more important
   - Launch overhead dominates when kernel execution time is <10 μs

2. **CPU-side Computation**:
   - Moving sparse_len to torch.full was counterproductive
   - Simple GPU writes are faster than host-side tensor creation
   - CPU-GPU synchronization adds latency

3. **Flattened Memory Layout**:
   - Flattening doesn't help when memory access is already coalesced
   - Adds reshape overhead without measurable benefit
   - View operations are tracked in profiling as overhead

### What We Confirmed

1. **Block Size Impact**:
   - BLOCK_SIZE=256 vs 128 has minimal impact (~5-10%)
   - For this workload, 128-256 are both reasonable choices

2. **Kernel Fusion is Critical**:
   - For small, compute-light kernels, fusion is essential
   - Launch overhead can easily exceed kernel execution time
   - Single fused kernel >>> multiple specialized kernels

## Opportunities for Iteration 3

Based on the analysis, iteration 3 should focus on:

1. **Return to Fused Kernel Architecture**:
   - Keep single kernel from iteration 1
   - Optimize memory access patterns WITHIN the fused kernel
   - Don't sacrifice fusion for theoretical memory benefits

2. **Optimize the Fused Kernel Itself**:
   - Improve memory access patterns in the existing fused kernel
   - Use better vectorization (vec4 loads/stores)
   - Optimize branch prediction and reduce divergence

3. **Reduce Work Per Program**:
   - Current approach: 1 program per (batch, head)
   - Alternative: 1 program per block of sequence elements
   - Could improve parallelism and cache utilization

4. **Early Exit Optimization**:
   - For sequences < sink_size + window_size, avoid kernel launch entirely
   - Return original tensors immediately on Python side

5. **Kernel Parameter Tuning**:
   - Experiment with smaller BLOCK_SIZE (64) for better cache utilization
   - Or larger BLOCK_SIZE (512) with more coalescing

## Next Steps for Iteration 3

**Primary Focus**: Optimize the fused kernel from iteration 1 with better memory patterns

**Plan**:
1. Return to single fused kernel architecture
2. Implement vectorized loads/stores (int4/float4) for memory bandwidth
3. Optimize loop unrolling and reduce branch divergence
4. Add early exit for short sequences
5. Experiment with BLOCK_SIZE tuning (64, 256, 512)

**Expected Impact**: 
- 15-25% speedup over iteration 1 (target: <0.033 ms)
- Better memory bandwidth utilization
- More consistent performance across sequence lengths

