# Iteration 3: Optimized Fused Kernel with Improved Parameters

## Optimization Strategy

**Goal**: Improve upon iteration 1 by keeping the fused kernel architecture but optimizing block size and reducing overhead.

**Approach**:
1. Kept single fused kernel (learned from iteration 2 that splitting is slower)
2. Reduced BLOCK_SIZE from 128 to 64 for better cache utilization
3. Used `torch.full` for sparse_len (constant value, simpler than GPU write)
4. Maintained early exit optimization for short sequences
5. Simplified kernel structure with better memory access patterns

## Implementation Details

**Key Changes from Iteration 1**:
- BLOCK_SIZE reduced from 128 to 64
- Used `torch.full` for sparse_len instead of GPU kernel write
- Kept same fused kernel architecture
- Added explicit early exit for short sequences

## Timing Results

### Baseline (gen_imperative_code.py)
```
custom __indexer:
  Average Time: 0.091 ms
  Min Time:     0.083 ms
  Max Time:     0.239 ms
```

### Iteration 1 (Fused Kernel, BLOCK_SIZE=128)
```
custom __indexer:
  Average Time: 0.039 ms  (2.3x faster than baseline)
  Min Time:     0.034 ms
  Max Time:     0.150 ms
```

### Iteration 2 (Split Kernels, BLOCK_SIZE=256) - REGRESSION
```
custom __indexer:
  Average Time: 0.054 ms  (1.7x faster than baseline, 1.4x slower than iter 1)
  Min Time:     0.045 ms
  Max Time:     0.204 ms
```

### Iteration 3 (Fused Kernel, BLOCK_SIZE=64)
```
custom __indexer:
  Average Time: 0.055 ms  (1.7x faster than baseline, similar to iter 2)
  Min Time:     0.048 ms  (+41.2% vs iteration 1)
  Max Time:     0.166 ms  (+10.7% vs iteration 1)
```

### Performance Comparison Table

| Iteration | Avg Time (ms) | Speedup vs Baseline | Speedup vs Best | CUDA Time (μs) |
|-----------|---------------|---------------------|-----------------|----------------|
| Baseline  | 0.091        | 1.0x               | 0.43x          | ~N/A           |
| Iteration 1 (BEST) | **0.039** | **2.3x**    | **1.0x**       | 8.544          |
| Iteration 2 | 0.054        | 1.7x               | 0.72x          | 6.464 (+ 2.688 overhead) |
| Iteration 3 | 0.055        | 1.7x               | 0.71x          | 15.936 (+ 2.368 overhead) |

## Profile Analysis

### Key Observations

**CUDA Kernel Timing** (from profile.log):
- `optimized_sparse_pattern_kernel`: 15.936 μs CUDA time
- `torch.full` overhead: 2.368 μs CUDA time  
- **Total CUDA time: ~18.3 μs vs 8.544 μs in iteration 1** (2.14x slower on GPU)

### Why Iteration 3 is Slower than Iteration 1

1. **Smaller Block Size Reduces Parallelism**:
   - BLOCK_SIZE=64 vs 128 means more iterations per kernel
   - For attended_len=256: 4 iterations (64) vs 2 iterations (128)
   - For seq_len_k=32678: 511 iterations (64) vs 256 iterations (128)
   - More loop iterations = higher loop overhead and worse GPU occupancy

2. **torch.full Adds Overhead**:
   - 2.368 μs CUDA time for torch.full call
   - Iteration 1 wrote sparse_len directly in kernel (~0 extra cost)
   - The "optimization" of moving to CPU/torch.full backfired

3. **Loop Overhead Dominates**:
   - Small BLOCK_SIZE = more loop iterations
   - Loop condition checks and increments add up
   - Triton loop optimization is less effective with more iterations

4. **Reduced Memory Coalescing**:
   - Smaller blocks can reduce memory bandwidth utilization
   - 64-element blocks may not saturate memory bus
   - Less efficient use of cache lines (typically 128 bytes)

### Comparison: Block Size Impact

| Block Size | CUDA Kernel Time | # Iterations (attended) | # Iterations (seq) | Wall Clock Time |
|------------|------------------|------------------------|--------------------|-----------------|
| 64 (Iter 3) | 15.936 μs | 4 | 511 | 0.055 ms |
| 128 (Iter 1) | 8.544 μs | 2 | 256 | **0.039 ms** |
| 256 (Iter 2) | 6.464 μs | 1 | 128 | 0.054 ms* |

*Iteration 2 has two separate kernels + torch.full overhead, so total is actually worse

## Lessons Learned

### Key Insights

1. **Block Size Sweet Spot**:
   - BLOCK_SIZE=128 is optimal for this workload
   - Too small (64): too many iterations, poor parallelism
   - Too large (256): doesn't help enough to offset kernel splitting overhead

2. **Kernel Fusion is Critical**:
   - Single fused kernel >> multiple specialized kernels
   - Launch overhead dominates for small kernels (<10 μs)
   - Keep related operations together

3. **Avoid Premature Optimization**:
   - torch.full seemed like a good idea (CPU-side constant)
   - Actually adds overhead vs simple GPU write
   - Direct GPU writes in kernel are very cheap

4. **Loop Count Matters**:
   - Fewer, larger blocks = better performance
   - Loop overhead is non-trivial in Triton
   - Balance between parallelism and iteration count

## Best Practices Identified

**For Small Triton Kernels (<100 μs)**:

1. **Fuse Everything**: Don't split kernels unless absolutely necessary
2. **Optimize Block Size**: Start with 128-256, benchmark up/down
3. **Minimize Iterations**: Larger blocks = fewer loops = better performance
4. **Avoid Trivial CPU Computation**: GPU writes are faster than torch ops
5. **Early Exit**: Skip kernel launch for degenerate cases

## Final Recommendation

**Use Iteration 1** as the production implementation:
- 2.3x speedup over baseline
- Simplest implementation
- Best performance
- Optimal BLOCK_SIZE=128
- No unnecessary overhead

## Optimization Ceiling Analysis

The current best implementation (iteration 1) achieves:
- CUDA kernel time: 8.544 μs
- Wall-clock time: 0.039 ms
- Overhead: 0.039 - 0.00854 = 0.0305 ms (78% of total time)

**Where does the time go?**
1. Kernel launch overhead: ~10-15 μs
2. CPU-GPU synchronization: ~10 μs  
3. Tensor allocations: ~5-10 μs
4. Python overhead: ~2-5 μs
5. Actual kernel execution: 8.544 μs (22% of time)

**Further optimization potential:**
- Kernel execution is already well-optimized (8.5 μs is good for this work)
- Main bottleneck is Python/PyTorch overhead (78% of time)
- To go faster: would need to fuse with attention computation (avoid Python calls)
- Practical limit for isolated indexer: ~0.030-0.035 ms (15-20% potential gain)

## Next Steps (Beyond Iteration 3)

If further optimization is needed:

1. **Fuse with Attention Backend**:
   - Combine indexer with attention computation
   - Eliminate intermediate tensor materialization
   - Single kernel for entire sparse attention

2. **JIT Compilation**:
   - Cache compiled kernels
   - Avoid recompilation overhead

3. **Batch-Level Optimization**:
   - Process multiple batch/head pairs in single kernel
   - Better GPU occupancy for small batch sizes

4. **Hardware-Specific Tuning**:
   - Tune BLOCK_SIZE for specific GPU architecture
   - Different optimal values for A100 vs V100 vs H100

5. **Algorithmic Change**:
   - Pre-compute sparse patterns
   - Cache and reuse for multiple forward passes
   - Only recompute when sequence length changes

