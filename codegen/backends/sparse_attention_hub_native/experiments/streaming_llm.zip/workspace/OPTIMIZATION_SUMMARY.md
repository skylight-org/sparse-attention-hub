# Sparse Attention Hub Native - Kernel Optimization Summary

## Overview

This document summarizes the optimization work performed on the `__indexer` function for the sparse_attention_hub_native backend. The function implements a Sink (128 tokens) + Local (128 tokens) sparse attention pattern.

## Baseline Performance

**Implementation**: Pure PyTorch operations (`gen_imperative_code.py`)
- Creates separate tensors using `torch.zeros`, `torch.arange`, `torch.full`
- Uses tensor slicing and broadcasting
- Multiple memory allocations and kernel launches

**Performance**:
- Average Time: **0.091 ms**
- Min Time: 0.083 ms
- Max Time: 0.239 ms

## Optimization Iterations

### Iteration 1: Fused Triton Kernel ✅ **BEST RESULT**

**Strategy**: Replace PyTorch operations with a single fused Triton kernel.

**Implementation**:
- Single kernel that generates sparse_list, weight_list, and sparse_len
- BLOCK_SIZE = 128
- Parallel processing: 1 program per (batch, head) pair
- Direct GPU memory writes

**Results**:
- Average Time: **0.039 ms** ⚡ **2.3x faster than baseline**
- Min Time: 0.034 ms (59% faster)
- Max Time: 0.150 ms (37% faster)
- CUDA Kernel Time: 8.544 μs
- **Correctness**: ✅ Passed all tests

**Why it works**:
- Kernel fusion eliminates multiple kernel launches
- Reduced memory allocations
- Efficient GPU parallelization
- Optimal block size for workload

---

### Iteration 2: Split Kernels with Memory Coalescing ❌ **REGRESSION**

**Strategy**: Separate kernels for better memory coalescing, larger block size.

**Implementation**:
- Two separate kernels: `sparse_list_kernel` and `weight_list_kernel`
- BLOCK_SIZE = 256
- Flattened memory layout
- Moved sparse_len to `torch.full`

**Results**:
- Average Time: **0.054 ms** ⚠️ **38% SLOWER than iteration 1**
- Min Time: 0.045 ms
- Max Time: 0.204 ms
- CUDA Kernel Time: 6.464 μs (kernels) + 2.688 μs (torch.full overhead)
- **Correctness**: ✅ Passed all tests

**Why it failed**:
- Kernel launch overhead dominates for small kernels
- Two launches >> single fused kernel
- torch.full adds unnecessary overhead
- Splitting trades compute efficiency for launch cost

**Lesson**: For small kernels (<10 μs), fusion is critical

---

### Iteration 3: Optimized Fused Kernel with Smaller Block Size ❌ **NO IMPROVEMENT**

**Strategy**: Return to fused kernel but optimize block size.

**Implementation**:
- Single fused kernel (learned from iteration 2)
- BLOCK_SIZE = 64 (smaller for "better cache utilization")
- torch.full for sparse_len
- Early exit for short sequences

**Results**:
- Average Time: **0.055 ms** ⚠️ **41% SLOWER than iteration 1**
- Min Time: 0.048 ms
- Max Time: 0.166 ms
- CUDA Kernel Time: 15.936 μs (2x slower than iteration 1!)
- **Correctness**: ✅ Passed all tests

**Why it failed**:
- Smaller block size = more loop iterations (511 vs 256)
- Loop overhead dominates: 4 iterations vs 2 for attended tokens
- Reduced GPU occupancy and memory bandwidth utilization
- torch.full still adds overhead

**Lesson**: Block size matters! Too small = poor parallelism and high loop overhead

---

## Performance Comparison

| Implementation | Avg Time (ms) | Speedup vs Baseline | CUDA Time (μs) | Status |
|----------------|---------------|---------------------|----------------|---------|
| **Baseline (PyTorch)** | 0.091 | 1.0x | ~N/A | Original |
| **Iteration 1 (Fused, BS=128)** | **0.039** | **2.3x** ⚡ | 8.544 | ✅ **BEST** |
| Iteration 2 (Split, BS=256) | 0.054 | 1.7x | 9.15 | ❌ Regression |
| Iteration 3 (Fused, BS=64) | 0.055 | 1.7x | 18.3 | ❌ No Improvement |

## Key Learnings

### 1. Kernel Fusion is Critical
- Single fused kernel >> multiple specialized kernels
- Launch overhead (10-20 μs) can exceed kernel execution time
- Keep related operations together

### 2. Block Size Optimization
- **Sweet spot**: BLOCK_SIZE = 128 for this workload
- Too small (64): high loop overhead, poor parallelism
- Too large (256): doesn't help enough when split across kernels
- Balance between iterations and parallelism

### 3. Avoid Premature Optimization
- Moving constants to CPU (torch.full) added overhead
- Direct GPU writes in kernel are very cheap
- Don't optimize away fast operations

### 4. Profile-Driven Development
- Assumptions about "better memory coalescing" didn't help
- Measure, don't guess
- Wall-clock time is what matters, not theoretical improvements

### 5. Overhead Analysis
In iteration 1 (best result):
- Kernel execution: 8.5 μs (22% of time)
- Python/PyTorch overhead: 30.5 μs (78% of time)
- Further gains require reducing Python overhead or fusing with attention

## Best Practices for Triton Optimization

### For Small Kernels (<100 μs)

1. **Fuse Everything**: Don't split unless absolutely necessary
2. **Start with BS=128-256**: Benchmark to find optimal size
3. **Minimize Loop Iterations**: Larger blocks = fewer loops = better perf
4. **Avoid Trivial CPU Ops**: GPU writes << torch.full/zeros/etc
5. **Early Exit**: Skip kernel launch for degenerate cases
6. **Profile First**: Measure before and after every change

### For This Workload

- Workload: 32 programs × (256 + 32678 elements)
- Optimal: Single fused kernel, BLOCK_SIZE=128
- Don't: Split kernels, use block size < 128 or > 256

## Production Recommendation

**Use Iteration 1** (`workspace/1/optimized_indexer.py`):

```python
# Single fused Triton kernel
# BLOCK_SIZE = 128
# Direct GPU writes for all outputs
# 2.3x speedup over baseline
```

**Why**:
- ✅ Best performance (0.039 ms average)
- ✅ Simplest implementation
- ✅ Proven correctness
- ✅ Optimal parameters
- ✅ No unnecessary overhead

## Future Optimization Opportunities

### Within Current Architecture
- **Ceiling**: ~0.030-0.035 ms (15-20% potential gain)
- Limited by Python/PyTorch overhead (78% of total time)
- Kernel execution already well-optimized

### Beyond Current Architecture

1. **Fuse with Attention Backend**:
   - Eliminate intermediate tensor materialization
   - Single kernel for entire sparse attention
   - Expected: 3-5x additional speedup

2. **JIT Compilation & Caching**:
   - Cache compiled kernels by (batch_size, num_heads, seq_len)
   - Avoid recompilation overhead
   - Expected: 10-20% speedup for repeated calls

3. **Pre-computation**:
   - Cache sparse patterns when sequence length doesn't change
   - Reuse across multiple forward passes
   - Expected: Near-zero cost for indexer in steady state

4. **Hardware-Specific Tuning**:
   - Auto-tune BLOCK_SIZE per GPU architecture
   - Different values for A100 (128) vs H100 (possibly 256)
   - Expected: 5-15% speedup on newer hardware

## Files and Artifacts

### Iteration Directories
- `workspace/1/`: Best result (fused kernel, BS=128) ✅
- `workspace/2/`: Split kernels (regression) ❌
- `workspace/3/`: Smaller block size (no improvement) ❌

### Key Files per Iteration
- `optimized_indexer.py`: Kernel implementation
- `profile.log`: Full profiling output
- `profile_*.json`: Chrome trace files (view in perfetto.dev)
- `profile_timing_summary.txt`: Quick timing results
- `summary.md`: Detailed analysis and learnings

### Correctness Testing
All iterations passed correctness tests:
```bash
python3 codegen/backends/sparse_attention_hub_native/correctness.py \
  --indexer-file codegen/backends/sparse_attention_hub_native/workspace/1/optimized_indexer.py
```

### Profiling Command
```bash
CUDA_VISIBLE_DEVICES=0 python3 codegen/backends/sparse_attention_hub_native/profile_indexer_hub.py \
  --output codegen/backends/sparse_attention_hub_native/workspace/1/profile \
  --indexer-file codegen/backends/sparse_attention_hub_native/workspace/1/optimized_indexer.py
```

## Conclusion

Through systematic optimization and careful profiling, we achieved a **2.3x speedup** over the baseline PyTorch implementation. The winning approach was a simple, fused Triton kernel with optimal block size (128) and no unnecessary overhead.

Key takeaway: **Simple and fused beats complex and split** for small kernels. Profile-driven development and learning from regressions (iterations 2 and 3) were essential to finding the best solution.

**Production Implementation**: Use `workspace/1/optimized_indexer.py` ✅

