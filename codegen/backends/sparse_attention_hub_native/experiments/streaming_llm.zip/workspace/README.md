# Kernel Optimization Results - sparse_attention_hub_native

## Quick Summary

Optimized the `__indexer` function for sparse attention pattern generation (Sink + Local window).

**Best Result**: Iteration 1 - **2.3x speedup** over baseline ✅

## Performance Results

| Implementation | Average Time | Speedup | Status |
|----------------|--------------|---------|---------|
| Baseline (PyTorch) | 0.091 ms | 1.0x | Original |
| **Iteration 1** ⭐ | **0.039 ms** | **2.3x** | ✅ **Best** |
| Iteration 2 | 0.054 ms | 1.7x | ❌ Regression |
| Iteration 3 | 0.055 ms | 1.7x | ❌ No improvement |

## Directory Structure

```
workspace/
├── README.md                      # This file
├── OPTIMIZATION_SUMMARY.md        # Comprehensive analysis
├── gen_imperative_code.py         # Baseline implementation
├── profile_results_*.json         # Baseline profiling
├── 1/                            # ✅ BEST - Use this!
│   ├── optimized_indexer.py      # Fused kernel, BLOCK_SIZE=128
│   ├── profile.log               # Full profiling output
│   ├── profile_*.json            # Trace files
│   └── summary.md                # Iteration 1 analysis
├── 2/                            # ❌ Regression
│   ├── optimized_indexer.py      # Split kernels experiment
│   └── summary.md                # Why it failed
└── 3/                            # ❌ No improvement
    ├── optimized_indexer.py      # Smaller block size
    └── summary.md                # Analysis
```

## Production Usage

**Use iteration 1:**

```python
# Import the optimized indexer
from workspace.1.optimized_indexer import __indexer

# It's a drop-in replacement for the baseline
# Same signature, same semantics, 2.3x faster
```

Or reference directly:
```bash
--indexer-file codegen/backends/sparse_attention_hub_native/workspace/1/optimized_indexer.py
```

## Testing

Run correctness check:
```bash
python3 codegen/backends/sparse_attention_hub_native/correctness.py \
  --indexer-file workspace/1/optimized_indexer.py
```

Run profiling:
```bash
CUDA_VISIBLE_DEVICES=0 python3 codegen/backends/sparse_attention_hub_native/profile_indexer_hub.py \
  --output workspace/1/profile \
  --indexer-file workspace/1/optimized_indexer.py
```

## Key Learnings

1. **Kernel Fusion Wins**: Single fused kernel >> multiple kernels
2. **Block Size Matters**: BLOCK_SIZE=128 is optimal for this workload
3. **Avoid Premature Optimization**: Splitting kernels for "better coalescing" made it slower
4. **Profile Everything**: Measure, don't guess

## What Made Iteration 1 Best?

✅ Single fused Triton kernel  
✅ Optimal BLOCK_SIZE (128)  
✅ Direct GPU writes (no torch.full overhead)  
✅ Minimal loop iterations  
✅ Simple and clean implementation  

## What Didn't Work?

❌ Splitting into separate kernels (iteration 2)  
❌ Smaller block size 64 (iteration 3)  
❌ Using torch.full for constants  
❌ Flattened memory layouts  

## Documentation

- `OPTIMIZATION_SUMMARY.md`: Complete analysis of all iterations
- `1/summary.md`: Detailed breakdown of iteration 1
- `2/summary.md`: Why split kernels failed
- `3/summary.md`: Block size analysis

## Viewing Profiles

All profile traces can be viewed at https://ui.perfetto.dev/

Load the `profile_*.json` files from each iteration directory.

## Contact

For questions or further optimization, refer to the detailed summaries in each iteration directory.

