"""Custom indexer implementing Sink + Local attention pattern.

This indexer implements the sparse attention pattern defined by:
- SinkMaskerConfig(sink_size=128): Attend to first 128 tokens
- LocalMaskerConfig(window_size=128): Attend to last 128 tokens (local window)

The implementation is imperative and self-contained, not using sparse_attention_hub
functions directly.
"""

from typing import Any, Dict, Tuple

import torch
from codegen.custom_attention_hub import sparse_attention_config # noqa: E402


def __indexer(
    queries: torch.Tensor,
    keys: torch.Tensor,
    values: torch.Tensor,
    sparse_list: torch.Tensor,
    sparse_len: torch.Tensor,
    weight_list: torch.Tensor,
    **kwargs: Dict[str, Any],
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Custom indexer implementing Sink (128) + Local (128) attention pattern.

    This function modifies the sparse attention pattern to attend only to:
    1. First 128 tokens (sink tokens)
    2. Last 128 tokens (local window)

    Args:
        queries: Query tensor of shape ``(batch_size, num_heads, head_dim)``.
        keys: Key tensor of shape ``(batch_size, num_heads, seq_len_k, head_dim)``.
        values: Value tensor of shape ``(batch_size, num_heads, seq_len_k, head_dim)``.
        sparse_list: Tensor of shape ``(batch_size, num_heads, seq_len_k)``
            containing token indices to attend to.
        sparse_len: Tensor of shape ``(batch_size, num_heads)`` indicating
            the valid length in sparse_list.
        weight_list: Tensor of shape ``(batch_size, num_heads, seq_len_k)``
            containing per-token weights.
        **kwargs: Additional keyword arguments (unused).

    Returns:
        Tuple of (sparse_list, sparse_len, weight_list) modified to implement
        the sink + local attention pattern.
    """
    # Configuration
    sink_size: int = sparse_attention_config.masker_configs[0].sink_size
    window_size: int = sparse_attention_config.masker_configs[1].window_size
    
    # Extract dimensions
    batch_size: int = keys.shape[0]
    num_heads: int = keys.shape[1]
    seq_len_k: int = keys.shape[2]
    
    device: torch.device = keys.device
    dtype: torch.dtype = weight_list.dtype
    
    # Handle case where sequence is shorter than sink + window
    if seq_len_k <= sink_size + window_size:
        # Use full attention - return all tokens
        return sparse_list, sparse_len, weight_list
    
    # Create new sparse_list with sink + local tokens
    # Shape: (batch_size, num_heads, sink_size + window_size)
    new_sparse_list: torch.Tensor = torch.zeros(
        (batch_size, num_heads, sink_size + window_size),
        dtype=torch.int32,
        device=device
    )
    
    # Sink tokens: indices [0, 1, 2, ..., sink_size-1]
    sink_indices: torch.Tensor = torch.arange(
        sink_size, dtype=torch.int32, device=device
    )
    new_sparse_list[:, :, :sink_size] = sink_indices.view(1, 1, sink_size)
    
    # Local window tokens: indices [seq_len_k - window_size, ..., seq_len_k - 1]
    local_indices: torch.Tensor = torch.arange(
        seq_len_k - window_size, seq_len_k, dtype=torch.int32, device=device
    )
    new_sparse_list[:, :, sink_size:] = local_indices.view(1, 1, window_size)
    
    # Update sparse_len to reflect the new number of attended tokens
    new_sparse_len: torch.Tensor = torch.full(
        (batch_size, num_heads),
        sink_size + window_size,
        dtype=torch.int32,
        device=device
    )
    
    # Create new weight_list: keep the same shape (B, H, seq_len_k) as input
    # weight_list is indexed by actual token position, not sparse_list position
    # Set weights to 0.0 for tokens NOT in sparse_list (will be clamped to 1e-30 in kernel)
    # Set weights to 1.0 for tokens in sparse_list (sink and local window)
    new_weight_list: torch.Tensor = torch.zeros(
        (batch_size, num_heads, seq_len_k),
        dtype=dtype,
        device=device
    )
    
    # Set weights for sink tokens (first sink_size positions)
    new_weight_list[:, :, :sink_size] = 1.0
    
    # Set weights for local window tokens (last window_size positions)
    new_weight_list[:, :, seq_len_k - window_size:] = 1.0
    
    return new_sparse_list, new_sparse_len, new_weight_list

