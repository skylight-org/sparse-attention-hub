"""Optimized Triton implementation of Sink + Local sparse attention indexer.

Iteration 1: Replace Python loops with Triton kernel for parallelization.

This module implements the core logic of sparse attention with:
- Sink attention: attending to the first `sink_size` tokens
- Local attention: attending to the last `window_size` tokens

The configuration matches:
    ResearchAttentionConfig(
        masker_configs=[
            SinkMaskerConfig(sink_size=128),
            LocalMaskerConfig(window_size=128)
        ]
    )
"""

from typing import List, Optional, Tuple

import torch
import triton
import triton.language as tl


# Configuration constants matching the sparse attention config
SINK_SIZE: int = 128
WINDOW_SIZE: int = 128


@triton.jit
def sparse_kv_copy_kernel(
    # Input pointers
    kv_cache_ptr,
    kv_page_indices_ptr,
    kv_last_page_len_ptr,
    # Output pointers
    new_kv_cache_ptr,
    new_kv_last_page_len_ptr,
    # Dimensions
    batch_size: tl.constexpr,
    num_kv_heads: tl.constexpr,
    head_dim: tl.constexpr,
    page_size: tl.constexpr,
    sink_size: tl.constexpr,
    window_size: tl.constexpr,
    effective_seq_len: tl.constexpr,
    # Strides for kv_cache: (num_pages, 2, page_size, num_kv_heads, head_dim)
    kv_stride_page,
    kv_stride_kv,
    kv_stride_pos,
    kv_stride_head,
    kv_stride_dim,
):
    """Triton kernel for extracting sparse KV positions (sink + local window).

    This kernel processes each batch element in parallel, extracting:
    - Sink tokens: first `sink_size` positions
    - Local window tokens: last `window_size` positions

    Args:
        kv_cache_ptr: Input KV cache pointer.
        kv_page_indices_ptr: Page indices for each batch element.
        kv_last_page_len_ptr: Original sequence lengths.
        new_kv_cache_ptr: Output KV cache pointer.
        new_kv_last_page_len_ptr: Output sequence lengths.
        batch_size: Number of batch elements.
        num_kv_heads: Number of KV heads.
        head_dim: Head dimension.
        page_size: Page size.
        sink_size: Number of sink tokens.
        window_size: Number of local window tokens.
        effective_seq_len: sink_size + window_size.
        kv_stride_*: Strides for the KV cache tensor.
    """
    # Get batch index and position index
    batch_idx: tl.int32 = tl.program_id(0)
    pos_idx: tl.int32 = tl.program_id(1)
    kv_type_idx: tl.int32 = tl.program_id(2)  # 0 for keys, 1 for values

    # Load sequence length and page index for this batch
    seq_len: tl.int32 = tl.load(kv_last_page_len_ptr + batch_idx).to(tl.int32)
    page_idx: tl.int32 = tl.load(kv_page_indices_ptr + batch_idx).to(tl.int32)

    # Determine if this position is valid
    is_valid: tl.int1 = pos_idx < tl.minimum(seq_len, effective_seq_len)

    # Determine source position in original KV cache
    src_pos: tl.int32 = 0
    if pos_idx < sink_size:
        # Sink region: copy from positions [0, sink_size)
        src_pos = pos_idx
    else:
        # Local window region: copy from positions [seq_len - window_size, seq_len)
        local_offset: tl.int32 = pos_idx - sink_size
        src_pos = seq_len - window_size + local_offset

    # Only process if position is valid and within bounds
    if is_valid and src_pos >= 0 and src_pos < seq_len:
        # Process all heads and dimensions for this position
        for head_idx in range(num_kv_heads):
            for dim_idx in range(head_dim):
                # Calculate source address
                src_offset: tl.int64 = (
                    page_idx * kv_stride_page +
                    kv_type_idx * kv_stride_kv +
                    src_pos * kv_stride_pos +
                    head_idx * kv_stride_head +
                    dim_idx * kv_stride_dim
                )

                # Calculate destination address
                dst_offset: tl.int64 = (
                    page_idx * kv_stride_page +
                    kv_type_idx * kv_stride_kv +
                    pos_idx * kv_stride_pos +
                    head_idx * kv_stride_head +
                    dim_idx * kv_stride_dim
                )

                # Load and store
                value: tl.float16 = tl.load(kv_cache_ptr + src_offset)
                tl.store(new_kv_cache_ptr + dst_offset, value)

    # Update new sequence lengths (only once per batch)
    if pos_idx == 0 and kv_type_idx == 0:
        new_seq_len: tl.int32 = tl.minimum(seq_len, effective_seq_len)
        tl.store(new_kv_last_page_len_ptr + batch_idx, new_seq_len.to(tl.int32))


def __indexer(
    q: torch.Tensor,
    kv_cache: torch.Tensor,
    kv_page_indptr: torch.Tensor,
    kv_page_indices: torch.Tensor,
    kv_last_page_len: torch.Tensor,
    num_qo_heads: int,
    num_kv_heads: int,
    head_dim: int,
    page_size: int,
    pos_encoding_mode: str = "NONE",
    data_type: torch.dtype = torch.float16,
    use_cuda_graph: bool = False,
    use_tensor_cores: bool = False,
    backend: str = "auto",
    jit_args: Optional[List[str]] = None,
) -> Tuple[
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    int,
    int,
    int,
    int,
    str,
    torch.dtype,
    bool,
    bool,
    str,
    Optional[List[str]],
]:
    """Implement Sink + Local sparse attention indexer using Triton.

    This function extracts only the KV positions that should be attended to according
    to the sparse attention pattern:
    - Sink: first SINK_SIZE tokens (positions 0 to SINK_SIZE-1)
    - Local: last WINDOW_SIZE tokens (positions seq_len-WINDOW_SIZE to seq_len-1)

    For decode mode (seq_len_q=1), this creates a sparse KV cache containing only
    the relevant positions.

    Args:
        q: Query tensor of shape (batch_size, num_heads, head_dim).
        kv_cache: KV cache tensor of shape (num_pages, 2, page_size, num_kv_heads, head_dim).
        kv_page_indptr: Page index pointers.
        kv_page_indices: Page indices.
        kv_last_page_len: Last page lengths (effective sequence lengths).
        num_qo_heads: Number of query/output heads.
        num_kv_heads: Number of key/value heads.
        head_dim: Head dimension.
        page_size: Page size.
        pos_encoding_mode: Position encoding mode.
        data_type: Data type for computation.
        use_cuda_graph: Whether to use CUDA graphs.
        use_tensor_cores: Whether to use tensor cores.
        backend: Backend selection.
        jit_args: JIT arguments.

    Returns:
        Tuple of all arguments with modified kv_cache and kv_last_page_len to implement
        sparse attention.
    """
    batch_size: int = q.shape[0]
    device: torch.device = q.device
    dtype: torch.dtype = kv_cache.dtype
    num_pages: int = kv_cache.shape[0]

    # Create new KV cache with only the sparse attention positions
    effective_seq_len: int = SINK_SIZE + WINDOW_SIZE

    # Initialize new KV cache (zeros)
    new_kv_cache: torch.Tensor = torch.zeros(
        num_pages,
        2,  # keys and values
        page_size,
        num_kv_heads,
        head_dim,
        dtype=dtype,
        device=device,
    )

    # Initialize new sequence lengths
    new_kv_last_page_len: torch.Tensor = torch.empty(
        batch_size,
        dtype=kv_last_page_len.dtype,
        device=device,
    )

    # Get strides for the KV cache
    kv_strides: Tuple[int, ...] = kv_cache.stride()

    # Launch Triton kernel
    # Grid: (batch_size, effective_seq_len, 2) where 2 is for keys and values
    grid = (batch_size, effective_seq_len, 2)

    sparse_kv_copy_kernel[grid](
        kv_cache_ptr=kv_cache,
        kv_page_indices_ptr=kv_page_indices,
        kv_last_page_len_ptr=kv_last_page_len,
        new_kv_cache_ptr=new_kv_cache,
        new_kv_last_page_len_ptr=new_kv_last_page_len,
        batch_size=batch_size,
        num_kv_heads=num_kv_heads,
        head_dim=head_dim,
        page_size=page_size,
        sink_size=SINK_SIZE,
        window_size=WINDOW_SIZE,
        effective_seq_len=effective_seq_len,
        kv_stride_page=kv_strides[0],
        kv_stride_kv=kv_strides[1],
        kv_stride_pos=kv_strides[2],
        kv_stride_head=kv_strides[3],
        kv_stride_dim=kv_strides[4],
    )

    # Return modified inputs
    return (
        q,
        new_kv_cache,
        kv_page_indptr,
        kv_page_indices,
        new_kv_last_page_len,
        num_qo_heads,
        num_kv_heads,
        head_dim,
        page_size,
        pos_encoding_mode,
        data_type,
        use_cuda_graph,
        use_tensor_cores,
        backend,
        jit_args,
    )

