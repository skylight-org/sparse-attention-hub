# Iteration 1 Summary

## Idea Tried
Replaced Python for loops with a Triton kernel to parallelize the sparse KV extraction. The kernel parallelizes across batch, position, and KV type (keys/values) dimensions, but uses nested Python-style loops within the kernel for heads and head dimensions.

## Timing Results

### Performance Metrics
- **custom_indexer_hub (reference)**: 0.113 ms average
- **custom __indexer (Iteration 1)**: 0.223 ms average

**Result**: Iteration 1 is **~2x slower** than the reference implementation.

### Detailed Profiling
From `profile.log`:
- `sparse_kv_copy_kernel` (Triton kernel): 180.224 μs
- `aten::zeros` (allocation): 2.302 μs  
- `aten::fill_` (initialization): 1.151 μs
- Total CUDA time: 181.375 μs

## Analysis

### Issues Identified

1. **Inefficient Memory Access Pattern**: The kernel uses nested loops (`for head_idx in range(num_kv_heads)`, `for dim_idx in range(head_dim)`) instead of vectorizing memory operations. This causes:
   - Poor memory coalescing
   - Underutilization of GPU parallelism
   - Sequential processing of what should be parallel work

2. **Suboptimal Grid Configuration**: Current grid is `(batch_size, effective_seq_len, 2)`, which launches 1 × 256 × 2 = 512 threads for batch_size=1, effective_seq_len=256. This is far below GPU occupancy.

3. **Inefficient Data Layout**: Processing one element at a time with nested loops doesn't leverage:
   - SIMD/vector operations
   - L1/L2 cache effectively
   - Memory bandwidth

4. **Conditional Branching**: Multiple `if` statements in the kernel cause thread divergence.

## Opportunities for Optimization (Iteration 2)

1. **Vectorized Memory Access**: 
   - Process entire head dimension vectors at once using `tl.load` with masks
   - Use `BLOCK_SIZE` for head dimension to enable coalescing
   - Parallelize across `(batch, position, head)` instead of `(batch, position, kv_type)`

2. **Better Thread Organization**:
   - Launch threads for each `(batch_idx, head_idx, pos_idx)` tuple
   - Process full head_dim vectors per thread using vectorized loads/stores
   - This would increase occupancy from ~512 to ~32K+ threads

3. **Reduce Branching**:
   - Precompute source positions for all threads
   - Use masked loads/stores instead of conditional execution

4. **Memory Coalescing**:
   - Ensure consecutive threads access consecutive memory locations
   - Align memory accesses to cache line boundaries

## Next Steps for Iteration 2
Rewrite the kernel with:
- Grid: `(batch_size, num_kv_heads, effective_seq_len)` 
- Each thread processes one `(batch, head, position)` and loads/stores the full `head_dim` vector
- Use vectorized `tl.load` and `tl.store` with `BLOCK_SIZE` for head_dim
- Eliminate nested loops in favor of vectorized operations

