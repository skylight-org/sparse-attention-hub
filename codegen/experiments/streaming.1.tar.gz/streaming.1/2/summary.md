# Iteration 2 Summary

## Idea Tried
Vectorized memory access with improved parallelization. Key changes from Iteration 1:
- Changed grid from `(batch, position, kv_type)` to `(batch, head, position)` 
- Each thread processes entire `head_dim` vectors using vectorized loads/stores
- Eliminated nested loops over heads and dimensions
- Processes both keys and values in the same thread to reduce kernel launches

## Timing Results

### Performance Metrics
- **custom_indexer_hub (reference)**: 0.116 ms average
- **custom __indexer (Iteration 2)**: 0.051 ms average

**Result**: Iteration 2 is **2.3x faster** than the reference implementation! 🎉

### Comparison with Iteration 1
- **Iteration 1**: 0.223 ms average
- **Iteration 2**: 0.051 ms average
- **Speedup**: **4.4x faster** than iteration 1

### Detailed Profiling
From `profile.log`:
- `sparse_kv_copy_kernel_vectorized` (Triton kernel): **5.377 μs** (vs 180.224 μs in iteration 1)
  - **33.5x kernel speedup!**
- `aten::zeros` (allocation): 2.240 μs
- `aten::fill_` (initialization): 1.120 μs
- Total CUDA time: 6.497 μs

### Grid Configuration
- Grid: `(1, 32, 256)` = 8,192 threads (vs 512 in iteration 1)
- Each thread processes 128 elements (head_dim) using vectorized loads
- Much better GPU occupancy

## Analysis

### What Worked Well

1. **Vectorized Memory Operations**: Using `tl.load` and `tl.store` with masks for entire `head_dim` vectors dramatically improved memory bandwidth utilization.

2. **Better Thread Organization**: Parallelizing over `(batch, head, position)` increased active threads from 512 to 8,192, significantly improving occupancy.

3. **Memory Coalescing**: Consecutive threads now access consecutive memory locations in the head dimension, enabling efficient coalesced memory access.

4. **Reduced Kernel Overhead**: Processing both keys and values in the same kernel thread reduces synchronization overhead.

### Remaining Bottlenecks

From the trace analysis, the main bottlenecks now are:

1. **Memory Allocation**: `torch.zeros` for creating `new_kv_cache` takes 2.240 μs - comparable to the kernel time itself (5.377 μs). This suggests allocation overhead is becoming significant.

2. **Initialization Overhead**: The `aten::fill_` operation for zero initialization adds overhead.

3. **Small Workload**: With batch_size=1 and only 256 positions to copy, the kernel is memory-bound rather than compute-bound. The actual data copying (5.377 μs) is very fast, but we're hitting memory latency limits.

## Opportunities for Optimization (Iteration 3)

1. **In-Place Modification**:
   - Instead of creating a new KV cache, modify the existing one in-place by:
     - Compacting the valid positions
     - Updating page indices/lengths
   - This eliminates the costly `torch.zeros` allocation

2. **Fused Allocation + Copy**:
   - If new allocation is necessary, use an uninitialized tensor (`torch.empty`) instead of `torch.zeros`
   - Zero out only the unused regions within the kernel

3. **Block-Level Optimization**:
   - Tune `BLOCK_SIZE` for head_dim=128 (currently uses `next_power_of_2(128)` = 128)
   - Consider processing multiple positions per thread to amortize fixed overhead

4. **Avoid Redundant Work**:
   - For sequences shorter than `sink_size + window_size`, we copy the entire sequence twice (once to destination)
   - Could detect this early and skip the kernel entirely

5. **Page Remapping Strategy**:
   - Instead of copying data, remap page indices to point to sink and window regions
   - This would be a zero-copy approach but requires changing the page table structure

## Next Steps for Iteration 3

Primary focus: **Eliminate memory allocation overhead**
- Use `torch.empty` instead of `torch.zeros`
- Add a kernel variant that zeros only unused positions
- Measure the impact of allocation vs computation time

Secondary focus: **Reduce data movement**
- Explore in-place compaction if feasible
- Consider whether the page structure allows for index remapping

The current kernel is already quite efficient (5.377 μs for the actual work), so further optimizations will likely come from reducing overhead rather than speeding up the kernel itself.

