"""Optimized Triton implementation of Sink + Local sparse attention indexer.

Iteration 3: Eliminate memory allocation overhead.

Improvements over Iteration 2:
- Use torch.empty instead of torch.zeros to avoid initialization overhead
- Kernel zeros out unused positions explicitly
- Reduces overall memory allocation time

The configuration matches:
    ResearchAttentionConfig(
        masker_configs=[
            SinkMaskerConfig(sink_size=128),
            LocalMaskerConfig(window_size=128)
        ]
    )
"""

from typing import List, Optional, Tuple

import torch
import triton
import triton.language as tl


# Configuration constants matching the sparse attention config
SINK_SIZE: int = 128
WINDOW_SIZE: int = 128


@triton.jit
def sparse_kv_copy_kernel_v3(
    # Input pointers
    kv_cache_ptr,
    kv_page_indices_ptr,
    kv_last_page_len_ptr,
    # Output pointers
    new_kv_cache_ptr,
    new_kv_last_page_len_ptr,
    # Dimensions
    batch_size: tl.constexpr,
    num_kv_heads: tl.constexpr,
    head_dim: tl.constexpr,
    page_size: tl.constexpr,
    sink_size: tl.constexpr,
    window_size: tl.constexpr,
    effective_seq_len: tl.constexpr,
    # Strides for kv_cache: (num_pages, 2, page_size, num_kv_heads, head_dim)
    kv_stride_page,
    kv_stride_kv,
    kv_stride_pos,
    kv_stride_head,
    kv_stride_dim,
    # Block sizes
    BLOCK_SIZE: tl.constexpr,
):
    """Optimized Triton kernel with minimal allocation overhead.

    This kernel processes each (batch, head, position) in parallel and:
    - Loads/stores entire head_dim vectors for valid positions
    - Zeros out invalid positions explicitly
    - Minimizes memory initialization overhead

    Args:
        kv_cache_ptr: Input KV cache pointer.
        kv_page_indices_ptr: Page indices for each batch element.
        kv_last_page_len_ptr: Original sequence lengths.
        new_kv_cache_ptr: Output KV cache pointer.
        new_kv_last_page_len_ptr: Output sequence lengths.
        batch_size: Number of batch elements.
        num_kv_heads: Number of KV heads.
        head_dim: Head dimension.
        page_size: Page size.
        sink_size: Number of sink tokens.
        window_size: Number of local window tokens.
        effective_seq_len: sink_size + window_size.
        kv_stride_*: Strides for the KV cache tensor.
        BLOCK_SIZE: Block size for vectorized access.
    """
    # Get program IDs
    batch_idx: tl.int32 = tl.program_id(0)
    head_idx: tl.int32 = tl.program_id(1)
    pos_idx: tl.int32 = tl.program_id(2)

    # Load sequence length and page index for this batch
    seq_len: tl.int32 = tl.load(kv_last_page_len_ptr + batch_idx).to(tl.int32)
    page_idx: tl.int32 = tl.load(kv_page_indices_ptr + batch_idx).to(tl.int32)

    # Check if this position is valid
    is_valid: tl.int1 = pos_idx < tl.minimum(seq_len, effective_seq_len)

    # Prepare dimension offsets and mask
    dim_offsets: tl.tensor = tl.arange(0, BLOCK_SIZE)
    dim_mask: tl.tensor = dim_offsets < head_dim

    # Compute source position
    src_pos: tl.int32 = 0
    if pos_idx < sink_size:
        src_pos = pos_idx
    else:
        local_offset: tl.int32 = pos_idx - sink_size
        src_pos = seq_len - window_size + local_offset

    # Process both keys and values
    if is_valid and src_pos >= 0 and src_pos < seq_len:
        # Keys (kv_type_idx = 0)
        src_base_k: tl.int64 = (
            page_idx * kv_stride_page +
            0 * kv_stride_kv +
            src_pos * kv_stride_pos +
            head_idx * kv_stride_head
        )
        dst_base_k: tl.int64 = (
            page_idx * kv_stride_page +
            0 * kv_stride_kv +
            pos_idx * kv_stride_pos +
            head_idx * kv_stride_head
        )

        src_ptrs_k: tl.tensor = kv_cache_ptr + src_base_k + dim_offsets * kv_stride_dim
        dst_ptrs_k: tl.tensor = new_kv_cache_ptr + dst_base_k + dim_offsets * kv_stride_dim
        values_k: tl.tensor = tl.load(src_ptrs_k, mask=dim_mask, other=0.0)
        tl.store(dst_ptrs_k, values_k, mask=dim_mask)

        # Values (kv_type_idx = 1)
        src_base_v: tl.int64 = (
            page_idx * kv_stride_page +
            1 * kv_stride_kv +
            src_pos * kv_stride_pos +
            head_idx * kv_stride_head
        )
        dst_base_v: tl.int64 = (
            page_idx * kv_stride_page +
            1 * kv_stride_kv +
            pos_idx * kv_stride_pos +
            head_idx * kv_stride_head
        )

        src_ptrs_v: tl.tensor = kv_cache_ptr + src_base_v + dim_offsets * kv_stride_dim
        dst_ptrs_v: tl.tensor = new_kv_cache_ptr + dst_base_v + dim_offsets * kv_stride_dim
        values_v: tl.tensor = tl.load(src_ptrs_v, mask=dim_mask, other=0.0)
        tl.store(dst_ptrs_v, values_v, mask=dim_mask)
    else:
        # Zero out invalid positions
        zeros: tl.tensor = tl.zeros([BLOCK_SIZE], dtype=tl.float16)

        # Zero keys
        dst_base_k: tl.int64 = (
            page_idx * kv_stride_page +
            0 * kv_stride_kv +
            pos_idx * kv_stride_pos +
            head_idx * kv_stride_head
        )
        dst_ptrs_k: tl.tensor = new_kv_cache_ptr + dst_base_k + dim_offsets * kv_stride_dim
        tl.store(dst_ptrs_k, zeros, mask=dim_mask)

        # Zero values
        dst_base_v: tl.int64 = (
            page_idx * kv_stride_page +
            1 * kv_stride_kv +
            pos_idx * kv_stride_pos +
            head_idx * kv_stride_head
        )
        dst_ptrs_v: tl.tensor = new_kv_cache_ptr + dst_base_v + dim_offsets * kv_stride_dim
        tl.store(dst_ptrs_v, zeros, mask=dim_mask)

    # Update new sequence lengths (only once per batch)
    if pos_idx == 0 and head_idx == 0:
        new_seq_len: tl.int32 = tl.minimum(seq_len, effective_seq_len)
        tl.store(new_kv_last_page_len_ptr + batch_idx, new_seq_len.to(tl.int32))


def __indexer(
    q: torch.Tensor,
    kv_cache: torch.Tensor,
    kv_page_indptr: torch.Tensor,
    kv_page_indices: torch.Tensor,
    kv_last_page_len: torch.Tensor,
    num_qo_heads: int,
    num_kv_heads: int,
    head_dim: int,
    page_size: int,
    pos_encoding_mode: str = "NONE",
    data_type: torch.dtype = torch.float16,
    use_cuda_graph: bool = False,
    use_tensor_cores: bool = False,
    backend: str = "auto",
    jit_args: Optional[List[str]] = None,
) -> Tuple[
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    int,
    int,
    int,
    int,
    str,
    torch.dtype,
    bool,
    bool,
    str,
    Optional[List[str]],
]:
    """Implement Sink + Local sparse attention indexer with minimal allocation overhead.

    This function extracts only the KV positions that should be attended to according
    to the sparse attention pattern:
    - Sink: first SINK_SIZE tokens (positions 0 to SINK_SIZE-1)
    - Local: last WINDOW_SIZE tokens (positions seq_len-WINDOW_SIZE to seq_len-1)

    For decode mode (seq_len_q=1), this creates a sparse KV cache containing only
    the relevant positions.

    Args:
        q: Query tensor of shape (batch_size, num_heads, head_dim).
        kv_cache: KV cache tensor of shape (num_pages, 2, page_size, num_kv_heads, head_dim).
        kv_page_indptr: Page index pointers.
        kv_page_indices: Page indices.
        kv_last_page_len: Last page lengths (effective sequence lengths).
        num_qo_heads: Number of query/output heads.
        num_kv_heads: Number of key/value heads.
        head_dim: Head dimension.
        page_size: Page size.
        pos_encoding_mode: Position encoding mode.
        data_type: Data type for computation.
        use_cuda_graph: Whether to use CUDA graphs.
        use_tensor_cores: Whether to use tensor cores.
        backend: Backend selection.
        jit_args: JIT arguments.

    Returns:
        Tuple of all arguments with modified kv_cache and kv_last_page_len to implement
        sparse attention.
    """
    batch_size: int = q.shape[0]
    device: torch.device = q.device
    dtype: torch.dtype = kv_cache.dtype
    num_pages: int = kv_cache.shape[0]

    # Create new KV cache with only the sparse attention positions
    effective_seq_len: int = SINK_SIZE + WINDOW_SIZE

    # Use torch.empty instead of torch.zeros to avoid initialization overhead
    # The kernel will explicitly zero out unused positions
    new_kv_cache: torch.Tensor = torch.empty(
        num_pages,
        2,  # keys and values
        page_size,
        num_kv_heads,
        head_dim,
        dtype=dtype,
        device=device,
    )

    # Initialize new sequence lengths
    new_kv_last_page_len: torch.Tensor = torch.empty(
        batch_size,
        dtype=kv_last_page_len.dtype,
        device=device,
    )

    # Get strides for the KV cache
    kv_strides: Tuple[int, ...] = kv_cache.stride()

    # Determine block size for vectorization (must be power of 2)
    BLOCK_SIZE: int = triton.next_power_of_2(head_dim)

    # Launch Triton kernel with vectorized access
    # Grid: (batch_size, num_kv_heads, effective_seq_len)
    grid = (batch_size, num_kv_heads, effective_seq_len)

    sparse_kv_copy_kernel_v3[grid](
        kv_cache_ptr=kv_cache,
        kv_page_indices_ptr=kv_page_indices,
        kv_last_page_len_ptr=kv_last_page_len,
        new_kv_cache_ptr=new_kv_cache,
        new_kv_last_page_len_ptr=new_kv_last_page_len,
        batch_size=batch_size,
        num_kv_heads=num_kv_heads,
        head_dim=head_dim,
        page_size=page_size,
        sink_size=SINK_SIZE,
        window_size=WINDOW_SIZE,
        effective_seq_len=effective_seq_len,
        kv_stride_page=kv_strides[0],
        kv_stride_kv=kv_strides[1],
        kv_stride_pos=kv_strides[2],
        kv_stride_head=kv_strides[3],
        kv_stride_dim=kv_strides[4],
        BLOCK_SIZE=BLOCK_SIZE,
    )

    # Return modified inputs
    return (
        q,
        new_kv_cache,
        kv_page_indptr,
        kv_page_indices,
        new_kv_last_page_len,
        num_qo_heads,
        num_kv_heads,
        head_dim,
        page_size,
        pos_encoding_mode,
        data_type,
        use_cuda_graph,
        use_tensor_cores,
        backend,
        jit_args,
    )

