# Iteration 3 Summary

## Idea Tried
Replace `torch.zeros` with `torch.empty` to eliminate initialization overhead, with the kernel explicitly zeroing out unused positions.

## Timing Results

### Performance Metrics
- **custom_indexer_hub (reference)**: 0.118 ms average
- **custom __indexer (Iteration 3)**: 0.047 ms average

**Result**: Iteration 3 is **2.5x faster** than the reference implementation! 🎉

### Comparison with Iteration 2
- **Iteration 2**: 0.051 ms average
- **Iteration 3**: 0.047 ms average
- **Improvement**: **~8% faster** (marginal improvement)

### Detailed Profiling
From `profile.log`:
- `sparse_kv_copy_kernel_v3` (Triton kernel): **5.760 μs** (vs 5.377 μs in iteration 2)
  - Kernel is slightly slower due to explicit zeroing logic
- `aten::empty` (allocation): minimal overhead (no fill operation)
- Total CUDA time: 5.760 μs

### Kernel Time Analysis
- **Iteration 2**: 5.377 μs
- **Iteration 3**: 5.760 μs
- **Change**: ~7% slower kernel execution

## Analysis

### Trade-offs

The change from `torch.zeros` to `torch.empty` had mixed results:

**Pros:**
- Eliminated CPU-side zero initialization overhead
- Slightly better overall timing (0.047 vs 0.051 ms)

**Cons:**
- Kernel itself is slightly slower (5.760 vs 5.377 μs) due to explicit zeroing of invalid positions
- Added branching and extra store operations in the kernel

The net improvement is marginal (~8%) because:
1. The original `torch.zeros` overhead was already quite small
2. The explicit zeroing in the kernel added overhead that partially offset the gains

### Current Performance Profile

At this point, the profiling shows:
- **Kernel execution**: 5.760 μs (very fast)
- **Overhead**: ~41 μs (CPU launch overhead, synchronization, etc.)
- **Total**: 47 μs average

The kernel itself is now highly optimized. The remaining time is dominated by:
- CUDA kernel launch overhead
- CPU-GPU synchronization
- Memory allocation

## Opportunities for Further Optimization (Iteration 4)

Given that the kernel is already fast (5.760 μs), further optimizations should focus on:

### 1. **Reduce Unnecessary Work for Small Sequences**
Currently, the kernel always processes `effective_seq_len` positions. For sequences shorter than `sink_size + window_size`, we could:
- Early-exit if `seq_len <= effective_seq_len`
- Simply copy the entire cache without the kernel
- This would avoid kernel launch overhead for small sequences

### 2. **Optimize for Common Case**
The current kernel handles three cases:
- `seq_len <= sink_size`
- `sink_size < seq_len <= effective_seq_len`  
- `seq_len > effective_seq_len`

The third case (long sequences) is likely most common. We could:
- Specialize the kernel for this case
- Avoid branching for short sequence handling

### 3. **Avoid Zeroing Unused Positions**
Currently, we zero positions beyond `effective_seq_len`. If the attention mechanism ignores these positions anyway (controlled by `kv_last_page_len`), we could:
- Skip zeroing entirely
- Let the attention mechanism handle masking
- This would eliminate the else branch with explicit zeros

### 4. **Batch Processing Optimization**
For `batch_size > 1`, we could:
- Process multiple batch elements per thread block
- Share page index loads across warps
- Better utilize shared memory

### 5. **In-Place Compaction**
A more radical approach:
- Modify the original `kv_cache` in-place by compacting positions
- Avoid allocating `new_kv_cache` entirely
- This requires careful handling to avoid overwriting data

## Next Steps for Iteration 4

**Primary focus**: Eliminate unnecessary zeroing and branching
- Skip explicit zeroing of invalid positions (rely on masking)
- Simplify kernel to handle only the common case (long sequences)
- This should bring kernel time back down to ~5 μs or below

**Secondary focus**: Reduce kernel launch overhead
- For very short sequences, bypass kernel entirely with a fast path
- Use a simple tensor copy when `seq_len <= effective_seq_len`

The goal is to get kernel time below 5 μs while maintaining or improving overall performance.

