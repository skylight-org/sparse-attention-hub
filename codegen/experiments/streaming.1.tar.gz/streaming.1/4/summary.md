# Iteration 4 Summary

## Idea Tried
Eliminate unnecessary zeroing and add fast path for short sequences:
- Remove explicit zeroing of invalid positions (rely on kv_last_page_len masking)
- Add fast path that bypasses kernel when `max_seq_len <= effective_seq_len`
- Simplified kernel with fewer branches

## Timing Results

### Performance Metrics
- **custom_indexer_hub (reference)**: 0.112 ms average
- **custom __indexer (Iteration 4)**: 0.049 ms average

**Result**: Iteration 4 is **2.3x faster** than the reference implementation! 🎉

### Comparison with Iteration 3
- **Iteration 3**: 0.047 ms average
- **Iteration 4**: 0.049 ms average
- **Change**: **~4% slower** (slight regression)

### Detailed Profiling
From `profile.log`:
- **Fast path triggered** in profiling (short sequence test case)
- `aten::max`: 6.272 μs (checking max sequence length)
- `aten::clone`: 2.752 μs (cloning cache for fast path)
- Total CUDA time: 9.472 μs (vs 5.760 μs in iteration 3)

### Analysis of Regression

The fast path check `kv_last_page_len.max()` adds overhead:
1. **Max operation**: 6.272 μs
2. **Item transfer**: 3.584 μs (GPU → CPU)
3. **Total overhead**: ~10 μs

For the profiling test case, the sequence is very short (len=1), so the fast path triggers and uses `clone()` instead of the kernel. However, the overhead of checking and cloning actually made it slightly slower than just running the optimized kernel directly.

## Key Insight

The fast path optimization backfired because:
- The max() operation requires a GPU reduction (6.272 μs)
- Transferring the result to CPU for comparison (3.584 μs)  
- This overhead (≈10 μs) is larger than the kernel execution itself (5-6 μs)!
- For very short sequences, clone() takes 2.752 μs, which is less than the kernel (5.760 μs), but the check overhead negates the benefit

## Opportunities for Further Optimization (Iteration 5)

### 1. **Remove Fast Path Check**
The fast path check adds more overhead than it saves. Options:
- Remove the check entirely - the kernel is fast enough for all cases
- Or only do the check if we can avoid GPU→CPU transfer (use a kernel parameter instead)

### 2. **Further Simplify Kernel Logic**
The current kernel still has nested if statements. We could:
- Assume `seq_len > effective_seq_len` (most common case)
- Remove edge case handling entirely
- This would eliminate all branching in the common path

### 3. **Optimize Block/Grid Configuration**
Currently: `grid = (batch_size, num_kv_heads, effective_seq_len)`
- Could tile the position dimension to improve memory access patterns
- Process multiple positions per thread to reduce total threads

### 4. **Use Shared Memory for Page Indices**
Currently each thread loads `page_idx` and `seq_len` independently:
- These are broadcast across all threads in a batch
- Could use shared memory to load once per block
- Would reduce global memory reads

### 5. **Fuse with Downstream Operation**
If the sparse KV cache is immediately used for attention:
- Could fuse the copy with the attention computation
- Avoid materializing the intermediate sparse cache
- This would be a more radical architectural change

## Next Steps for Iteration 5

**Primary focus**: Remove the fast path check entirely
- The kernel is already fast enough (5-6 μs)
- Checking for short sequences adds more overhead than it saves
- Simplicity is better here

**Secondary focus**: Optimize kernel for the common case only  
- Assume `seq_len > effective_seq_len`
- Remove branching for edge cases
- Aim to get kernel time below 5 μs

The goal is to get back to or below the iteration 3 performance (0.047 ms) by removing unnecessary overhead.

