# Sparse Attention Indexer Optimization Summary

This document summarizes the iterative optimization process for the Sink + Local sparse attention indexer implementation.

## Objective

Optimize the `__indexer()` function that extracts sparse KV positions (sink + local window) for efficient attention computation. The baseline implementation used Python loops to process the KV cache.

## Configuration

- **Sparse Pattern**: Sink (128 tokens) + Local Window (128 tokens)
- **Test Setup**: 
  - Batch size: 1
  - Num heads: 32
  - Head dim: 128
  - Sequence length: 32,678
  - Page size: varies by test

## Iteration Results

| Iteration | Approach | Kernel Time | Total Time | vs Reference | Key Changes |
|-----------|----------|-------------|------------|--------------|-------------|
| Baseline | Python loops | N/A | 113 μs | 1.0x | Original implementation |
| **1** | Basic Triton kernel | 180.224 μs | 223 μs | **0.5x (slower)** | Replaced loops with kernel, but nested loops inside |
| **2** | Vectorized access | 5.377 μs | 51 μs | **2.3x faster** | Vectorized loads/stores, better grid config |
| **3** | Avoid initialization | 5.760 μs | 47 μs | **2.5x faster** | torch.empty instead of zeros |
| **4** | Fast path | N/A | 49 μs | **2.4x faster** | Added short sequence check (regressed) |
| **5** | Simplified kernel | 5.441 μs | 44 μs | **2.7x faster** | Removed fast path, branchless logic |

## Detailed Iteration Analysis

### Iteration 1: Basic Triton Parallelization ❌

**Idea**: Replace Python for loops with Triton kernel.

**Implementation**:
- Grid: `(batch_size, effective_seq_len, 2)` 
- Nested Python-style loops for heads and dimensions inside kernel
- Sequential processing within each thread

**Results**:
- ❌ **2x slower** than baseline (223 μs vs 113 μs)
- Kernel time: 180.224 μs
- Poor memory coalescing and low GPU occupancy

**Lesson**: Naive parallelization without vectorization performs poorly.

---

### Iteration 2: Vectorized Memory Access ✅

**Idea**: Process entire head_dim vectors at once with better parallelization.

**Implementation**:
- Grid: `(batch_size, num_kv_heads, effective_seq_len)` - increased from 512 to 8,192 threads
- Vectorized loads/stores using `tl.load`/`tl.store` with masks
- Each thread processes one `(batch, head, position)` tuple
- Eliminated nested loops

**Results**:
- ✅ **2.3x faster** than baseline (51 μs vs 113 μs)
- Kernel time: 5.377 μs (**33.5x faster** than iteration 1!)
- Excellent memory coalescing and GPU occupancy

**Lesson**: Vectorized memory access is critical for GPU performance.

---

### Iteration 3: Eliminate Initialization Overhead ✅

**Idea**: Use `torch.empty` instead of `torch.zeros` to avoid unnecessary initialization.

**Implementation**:
- Changed allocation from `torch.zeros()` to `torch.empty()`
- Kernel explicitly zeros only invalid positions
- Relies on `kv_last_page_len` masking for correctness

**Results**:
- ✅ **2.5x faster** than baseline (47 μs vs 113 μs)
- Kernel time: 5.760 μs (slightly slower due to explicit zeroing)
- Overall ~8% improvement from reduced allocation overhead

**Lesson**: Small improvements come from reducing overhead, but kernel changes can have trade-offs.

---

### Iteration 4: Fast Path for Short Sequences ❌

**Idea**: Add fast path to bypass kernel for short sequences.

**Implementation**:
- Check `kv_last_page_len.max()` before kernel launch
- If `max_seq_len <= effective_seq_len`, use `clone()` instead of kernel
- Avoid kernel overhead for trivial cases

**Results**:
- ❌ **Slight regression** (49 μs vs 47 μs in iteration 3)
- Fast path check overhead:
  - `max()` operation: 6.272 μs
  - GPU→CPU transfer: 3.584 μs
  - Total: ~10 μs overhead
- Fast path saves only ~3 μs in ideal case
- Net negative impact

**Lesson**: Checking for optimizations can cost more than the optimization itself.

---

### Iteration 5: Simplified, Branchless Kernel ✅ **BEST**

**Idea**: Remove fast path overhead and simplify kernel with branchless logic.

**Implementation**:
- Removed fast path check entirely
- Branchless source position selection using `tl.where(is_sink, sink_src, window_src)`
- Early exit for invalid positions
- Focus on universal fast performance

**Results**:
- ✅ **2.7x faster** than baseline (44 μs vs 113 μs)
- Kernel time: 5.441 μs
- **Best overall performance**
- Consistent performance across all sequence lengths

**Time Breakdown**:
- Kernel execution: 5.441 μs (12%)
- Kernel launch overhead: ~35 μs (80%)
- Memory allocation: ~3-4 μs (8%)

**Lesson**: Simplicity and consistency beat clever micro-optimizations.

---

## Key Insights

### 1. Vectorization is Everything
The jump from iteration 1 (180 μs kernel) to iteration 2 (5.4 μs kernel) represents a **33x speedup** purely from:
- Vectorized memory access
- Better grid configuration
- Proper parallelization strategy

### 2. Bottleneck Migration
As we optimized:
- **Start**: Kernel computation bottleneck (180 μs)
- **End**: Kernel launch overhead bottleneck (35 μs)

The kernel now takes only 5.4 μs (12% of total time). Further improvements require architectural changes, not kernel tuning.

### 3. Avoid Premature Optimization
The fast path in iteration 4 seemed clever but added net overhead. The simpler approach in iteration 5 performed better.

### 4. Memory Access Patterns Matter
Coalesced memory access patterns (consecutive threads accessing consecutive memory) were critical for performance.

## Recommendations

### For Production Use
**Use Iteration 5** - it provides:
- ✅ 2.7x speedup (113 μs → 44 μs)
- ✅ Clean, maintainable code
- ✅ Robust for all sequence lengths
- ✅ Near-optimal kernel performance

### For Further Optimization
To improve beyond 44 μs, consider:

1. **Kernel Batching**: Launch multiple operations in parallel to amortize launch overhead
2. **CUDA Graphs**: Pre-record kernel launches to reduce launch overhead
3. **Fusion**: Fuse the copy operation with downstream attention computation
4. **Persistent Kernels**: Keep kernels running for streaming scenarios

These require architectural changes beyond single-kernel optimization.

## Code Locations

All implementations are in `/data/apdesai/code/sparse-attention-hub/codegen/workspace/`:
- `1/optimized_indexer.py` - Iteration 1 (basic parallelization)
- `2/optimized_indexer.py` - Iteration 2 (vectorized access)
- `3/optimized_indexer.py` - Iteration 3 (avoid initialization)
- `4/optimized_indexer.py` - Iteration 4 (fast path - not recommended)
- `5/optimized_indexer.py` - **Iteration 5 (RECOMMENDED)**

Each directory contains:
- `optimized_indexer.py` - Implementation
- `summary.md` - Detailed analysis
- `profile.log` - Full profiling output
- `profile_timing_summary.txt` - Timing summary
- `profile_*.json` - Trace files for visualization

## Performance Visualization

```
Baseline: ████████████████████████ 113 μs
Iter 1:   ███████████████████████████████████████ 223 μs (SLOWER!)
Iter 2:   ███████████ 51 μs (2.3x faster)
Iter 3:   ██████████ 47 μs (2.5x faster)
Iter 4:   ███████████ 49 μs (2.4x faster)
Iter 5:   █████████ 44 μs (2.7x faster) ⭐ BEST
```

## Conclusion

Through systematic optimization, we achieved a **2.7x speedup** with iteration 5. The kernel execution time improved by **33x** from iteration 1 to iteration 5 (180 μs → 5.4 μs). The remaining overhead is primarily kernel launch latency, which is a fundamental CUDA limitation for single kernel invocations.

**Iteration 5 represents the optimal balance of performance, code clarity, and maintainability** for a standalone indexing operation.

