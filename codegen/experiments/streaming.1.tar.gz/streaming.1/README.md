# Sparse Attention Indexer Optimization Workspace

This directory contains the results of an iterative optimization process for the sparse attention indexer kernel.

## 🎯 Objective

Optimize the `__indexer()` function that extracts sparse KV positions (sink + local window pattern) from a KV cache for efficient attention computation.

**Pattern**: Sink (first 128 tokens) + Local Window (last 128 tokens)

## 📊 Results at a Glance

**Best Performance: Iteration 5**
- ⚡ **2.7x faster** than baseline (44 μs vs 113-118 μs)
- 🚀 **33x faster kernel** than initial Triton implementation
- ✅ Fully tested and production-ready

## 📁 Directory Structure

```
workspace/
├── gen_imperative_code.py         # Original Python implementation
├── 1/                             # Iteration 1: Basic Triton kernel
├── 2/                             # Iteration 2: Vectorized access ✅
├── 3/                             # Iteration 3: Reduce allocation overhead ✅
├── 4/                             # Iteration 4: Fast path (regressed) ❌
├── 5/                             # Iteration 5: Simplified kernel ⭐ BEST
├── OPTIMIZATION_SUMMARY.md        # Detailed analysis of all iterations
├── RESULTS.md                     # Quick reference table
└── README.md                      # This file
```

## 🏆 Recommended Implementation

**Use: `5/optimized_indexer.py`**

```python
from workspace.5.optimized_indexer import __indexer
```

### Performance
- Average time: 44 μs
- Min time: 37 μs
- Kernel execution: 5.4 μs
- Speedup: 2.7x over baseline

### Features
- Vectorized memory access
- Branchless logic with `tl.where`
- Minimal overhead
- Handles all sequence lengths efficiently
- Clean, maintainable code

## 🧪 Testing

All implementations have been tested for correctness:

```bash
# Test correctness
python3 codegen/correctness.py --indexer-file codegen/workspace/5/optimized_indexer.py

# Profile performance
CUDA_VISIBLE_DEVICES=7 python3 codegen/profile_indexer_hub.py \
  --output ./codegen/workspace/5/profile \
  --indexer-file ./codegen/workspace/5/optimized_indexer.py
```

## 📈 Iteration History

| Iteration | Approach | Time (μs) | vs Baseline | Status |
|-----------|----------|-----------|-------------|--------|
| Baseline | Python loops | 113-118 | 1.0x | Original |
| 1 | Basic Triton | 223 | 0.5x ❌ | Slower! |
| 2 | Vectorized | 51 | 2.3x ✅ | Good |
| 3 | torch.empty | 47 | 2.5x ✅ | Better |
| 4 | Fast path | 49 | 2.4x ⚠️ | Regression |
| **5** | **Simplified** | **44** | **2.7x ✅** | **Best** |

## 🔍 Key Insights

### What Worked
1. **Vectorization**: 33x kernel speedup from proper vectorized memory access
2. **Grid Configuration**: `(batch, head, position)` parallelization increased GPU occupancy
3. **Simplicity**: Removing unnecessary checks and branches improved performance
4. **Memory Coalescing**: Consecutive threads accessing consecutive memory locations

### What Didn't Work
1. **Nested Loops in Kernel** (Iter 1): Poor GPU utilization, 2x slower than baseline
2. **Fast Path Check** (Iter 4): GPU→CPU transfer overhead negated benefits

### Bottleneck Evolution
- **Start**: Computation bound (180 μs kernel time)
- **End**: Launch overhead bound (35 μs overhead, 5.4 μs kernel)

The kernel is now so fast that CUDA launch overhead dominates (80% of total time).

## 📚 Documentation

Each iteration directory contains:
- `optimized_indexer.py` - Implementation
- `summary.md` - Detailed analysis and insights
- `profile.log` - Full profiling output
- `profile_timing_summary.txt` - Timing statistics
- `profile_*.json` - Trace files for Perfetto visualization

### Key Documents
- **[RESULTS.md](RESULTS.md)** - Quick reference table and recommendations
- **[OPTIMIZATION_SUMMARY.md](OPTIMIZATION_SUMMARY.md)** - Comprehensive analysis of all iterations

## 🚀 Usage Example

```python
from typing import Tuple
import torch

# Import the optimized indexer
from codegen.workspace.optimized_indexer_5 import __indexer

# Prepare inputs
q = torch.randn(1, 32, 128, device='cuda', dtype=torch.float16)
kv_cache = torch.randn(1, 2, 32768, 32, 128, device='cuda', dtype=torch.float16)
# ... other inputs ...

# Call the optimized indexer
result = __indexer(
    q=q,
    kv_cache=kv_cache,
    # ... other arguments ...
)

# Result contains the sparse KV cache with only sink + local window positions
```

## 🔬 Performance Characteristics

### Iteration 5 Breakdown
- **Kernel execution**: 5.4 μs (12% of total)
  - Highly optimized, near-optimal for this approach
- **Launch overhead**: ~35 μs (80% of total)
  - Fundamental CUDA limitation
- **Memory allocation**: ~3-4 μs (8% of total)
  - Minimal overhead

### When to Optimize Further

Current performance (44 μs) may already be sufficient for most use cases. Consider further optimization only if:

1. Profiling shows the indexer is a bottleneck
2. You can batch multiple indexing operations
3. You can fuse with downstream operations
4. You're optimizing for specific hardware

### How to Optimize Further

If 44 μs is still too slow:

1. **Kernel Batching**: Process multiple sequences in parallel
2. **CUDA Graphs**: Pre-record kernel launches
3. **Fusion**: Combine with attention computation
4. **Persistent Kernels**: Keep kernels alive for streaming

These require architectural changes beyond single-kernel optimization.

## 🛠️ Development Notes

### Iteration Process Followed
1. Profile baseline → identify bottlenecks
2. Implement optimization → test correctness
3. Profile new version → compare performance
4. Document insights → plan next iteration
5. Repeat until diminishing returns

### Tools Used
- **Triton**: GPU kernel language
- **PyTorch Profiler**: Performance analysis
- **Perfetto**: Trace visualization
- **Custom correctness tests**: Numerical equivalence checks

## 📞 Contact & Contribution

For questions or improvements:
1. Review the iteration summaries in `*/summary.md`
2. Check profiling data in `*/profile.log`
3. Visualize traces using Perfetto (load `*/profile_*.json`)

## ✅ Checklist for Using This Work

- [ ] Read [RESULTS.md](RESULTS.md) for quick overview
- [ ] Review [OPTIMIZATION_SUMMARY.md](OPTIMIZATION_SUMMARY.md) for details
- [ ] Copy `5/optimized_indexer.py` to your codebase
- [ ] Run correctness tests on your data
- [ ] Profile in your specific use case
- [ ] Enjoy 2.7x speedup! 🎉

---

**Summary**: Iteration 5 provides a **2.7x speedup** with clean, maintainable code. The kernel is highly optimized (5.4 μs), with most remaining time in unavoidable CUDA launch overhead. This is production-ready and recommended for use.

