"""Imperative implementation of Sink + Local sparse attention indexer.

This module implements the core logic of sparse attention with:
- Sink attention: attending to the first `sink_size` tokens
- Local attention: attending to the last `window_size` tokens

The configuration matches:
    ResearchAttentionConfig(
        masker_configs=[
            SinkMaskerConfig(sink_size=128),
            LocalMaskerConfig(window_size=128)
        ]
    )
"""

from typing import List, Optional, Tuple

import torch


# Configuration constants matching the sparse attention config
SINK_SIZE: int = 128
WINDOW_SIZE: int = 128


def __indexer(
    q: torch.Tensor,
    kv_cache: torch.Tensor,
    kv_page_indptr: torch.Tensor,
    kv_page_indices: torch.Tensor,
    kv_last_page_len: torch.Tensor,
    num_qo_heads: int,
    num_kv_heads: int,
    head_dim: int,
    page_size: int,
    pos_encoding_mode: str = "NONE",
    data_type: torch.dtype = torch.float16,
    use_cuda_graph: bool = False,
    use_tensor_cores: bool = False,
    backend: str = "auto",
    jit_args: Optional[List[str]] = None,
) -> Tuple[
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    torch.Tensor,
    int,
    int,
    int,
    int,
    str,
    torch.dtype,
    bool,
    bool,
    str,
    Optional[List[str]],
]:
    """Implement Sink + Local sparse attention indexer.

    This function extracts only the KV positions that should be attended to according
    to the sparse attention pattern:
    - Sink: first SINK_SIZE tokens (positions 0 to SINK_SIZE-1)
    - Local: last WINDOW_SIZE tokens (positions seq_len-WINDOW_SIZE to seq_len-1)

    For decode mode (seq_len_q=1), this creates a sparse KV cache containing only
    the relevant positions.

    Args:
        q: Query tensor of shape (batch_size, num_heads, head_dim).
        kv_cache: KV cache tensor of shape (num_pages, 2, page_size, num_kv_heads, head_dim).
        kv_page_indptr: Page index pointers.
        kv_page_indices: Page indices.
        kv_last_page_len: Last page lengths (effective sequence lengths).
        num_qo_heads: Number of query/output heads.
        num_kv_heads: Number of key/value heads.
        head_dim: Head dimension.
        page_size: Page size.
        pos_encoding_mode: Position encoding mode.
        data_type: Data type for computation.
        use_cuda_graph: Whether to use CUDA graphs.
        use_tensor_cores: Whether to use tensor cores.
        backend: Backend selection.
        jit_args: JIT arguments.

    Returns:
        Tuple of all arguments with modified kv_cache and kv_last_page_len to implement
        sparse attention.
    """
    batch_size: int = q.shape[0]
    device: torch.device = q.device
    dtype: torch.dtype = kv_cache.dtype
    num_pages: int = kv_cache.shape[0]

    # Create new KV cache with only the sparse attention positions
    # For each sequence, we'll keep: sink_size + window_size positions
    effective_seq_len: int = SINK_SIZE + WINDOW_SIZE

    # Initialize new KV cache maintaining the page structure
    # Shape: (num_pages, 2, page_size, num_kv_heads, head_dim)
    new_kv_cache: torch.Tensor = torch.zeros(
        num_pages,
        2,  # keys and values
        page_size,
        num_kv_heads,
        head_dim,
        dtype=dtype,
        device=device,
    )

    # Process each batch element
    for batch_idx in range(batch_size):
        # Get the original sequence length for this batch element
        seq_len: int = int(kv_last_page_len[batch_idx].item())

        # Get the page index for this batch element
        page_idx: int = int(kv_page_indices[batch_idx].item())

        # Handle edge case where sequence is shorter than sink + window
        if seq_len <= SINK_SIZE:
            # If sequence is shorter than sink size, copy entire sequence
            new_kv_cache[page_idx, :, :seq_len, :, :] = kv_cache[page_idx, :, :seq_len, :, :]
        elif seq_len <= SINK_SIZE + WINDOW_SIZE:
            # If sequence fits within sink + window, copy the entire sequence
            new_kv_cache[page_idx, :, :seq_len, :, :] = kv_cache[page_idx, :, :seq_len, :, :]
        else:
            # Normal case: sequence is longer than sink + window
            # Extract sink tokens (first SINK_SIZE positions)
            new_kv_cache[page_idx, :, :SINK_SIZE, :, :] = kv_cache[page_idx, :, :SINK_SIZE, :, :]

            # Extract local window tokens (last WINDOW_SIZE positions)
            # Calculate the start position of the local window
            local_start: int = seq_len - WINDOW_SIZE

            # Copy local window tokens to positions right after sink
            new_kv_cache[page_idx, :, SINK_SIZE:effective_seq_len, :, :] = \
                kv_cache[page_idx, :, local_start:seq_len, :, :]

    # Update kv_last_page_len to reflect the new effective sequence lengths
    new_kv_last_page_len: torch.Tensor = torch.empty(
        batch_size,
        dtype=kv_last_page_len.dtype,
        device=device,
    )

    # Adjust for sequences shorter than effective_seq_len
    for batch_idx in range(batch_size):
        seq_len: int = int(kv_last_page_len[batch_idx].item())
        new_kv_last_page_len[batch_idx] = min(seq_len, effective_seq_len)

    # Return modified inputs
    # Note: We keep the same page structure but with modified cache
    return (
        q,
        new_kv_cache,
        kv_page_indptr,
        kv_page_indices,
        new_kv_last_page_len,
        num_qo_heads,
        num_kv_heads,
        head_dim,
        page_size,
        pos_encoding_mode,
        data_type,
        use_cuda_graph,
        use_tensor_cores,
        backend,
        jit_args,
    )

